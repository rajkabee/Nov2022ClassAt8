module hellofx {
    requires javafx.controls;

    exports hellofx;
}